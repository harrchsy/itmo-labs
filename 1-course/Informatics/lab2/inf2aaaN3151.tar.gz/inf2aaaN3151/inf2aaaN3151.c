#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void print_binary_uint16(uint16_t x) {
  for (int bit = 15; bit >= 0; bit--) {
    putchar((x & (1u << bit)) ? '1' : '0');
    if (bit == 8)
      putchar(' ');
  }
  putchar('\n');
}

static int count_zeros(uint8_t b) {
  int c = 0;
  for (int i = 0; i < 8; i++)
    if (((b >> i) & 1u) == 0)
      c++;
  return c;
}

uint8_t move_zeros_to_high(uint8_t b) {
  int zeros = count_zeros(b);
  int ones = 8 - zeros;

  uint8_t result = 0;

  for (int i = 0; i < ones; i++)
    result |= (1u << i);

  return result;
}

uint8_t move_zeros_to_low(uint8_t b) {
  int zeros = count_zeros(b);
  int ones = 8 - zeros;

  uint8_t result = 0;

  for (int i = 0; i < ones; i++)
    result |= (1u << (8 - 1 - i));

  return result;
}

int main(int argc, char **argv) {
  uint16_t value;
  int have_arg = (argc >= 2);

  if (have_arg) {
    errno = 0;
    long long temp;
    if (sscanf(argv[1], "%lli", &temp) != 1 || errno != 0) {
      fprintf(stderr, "Ошибка: '%s' не является числом.\n", argv[1]);
      return 1;
    }

    value = (uint16_t)temp;
  } else {
    srand((unsigned)time(NULL));
    value = (uint16_t)rand();
  }

  print_binary_uint16(value);

  uint8_t low = (uint8_t)(value & 0x00FF);
  uint8_t high = (uint8_t)((value >> 8) & 0xFF);

  uint8_t new_low = move_zeros_to_high(low);
  uint8_t new_high = move_zeros_to_low(high);

  uint16_t result = ((uint16_t)new_high << 8) | new_low;

  value = result;

  print_binary_uint16(value);

  return 0;
}
