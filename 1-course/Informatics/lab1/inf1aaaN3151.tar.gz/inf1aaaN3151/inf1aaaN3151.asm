R00 <- 0
R01 <- 127

R02 <- @0x80
@0xFF <- R02
R02 <- 0

LOOP: RF <- R00 ~ R01
      RC <- @FINISH(Z)
      R00 <- R00++

      R02 <- @0x80
      R03 <- @0xFF
      RF <- R03 ~ R02
      RC <- @CONTINUE(S)

      @0xFF <- R02

CONTINUE: R02 <- @0x0F
      R02 <- R02++
      @0x0F <- R02

      RC <- @LOOP

FINISH: RC <- @FINISH
