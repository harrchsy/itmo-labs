import sys
import functools
from datetime import datetime
from typing import Any, Callable, Optional, Type


def _get_timestamp() -> str:
    return datetime.now().strftime("%d.%m.%y %H:%M:%S")


def _log_message(
    log_file: Optional[str],
    func_name: str,
    args: tuple,
    kwargs: dict,
    result: Any,
    replacements: list[tuple[Any, Any, str]]
) -> None:
    out = sys.stderr if log_file is None else open(log_file, 'a', encoding='utf-8')
    try:
        timestamp: str = _get_timestamp()
        print(f"{timestamp} {func_name}(args={args}, kwargs={kwargs}) -> {result}", file=out)
        for old_val, new_val, desc in replacements:
            print(f"{timestamp} {func_name}: аргумент {old_val} ({desc}) заменен на {new_val}", file=out)
    finally:
        if log_file is not None and hasattr(out, 'close'):
            out.close()


def shuffle_str_args(prng, log_file: Optional[str] = None) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            replacements: list[tuple[Any, Any, str]] = []
            new_args: list = []

            for i, arg in enumerate(args):
                if isinstance(arg, str):
                    shuffled: str = prng.shuffle_str(arg)
                    new_args.append(shuffled)
                    replacements.append((arg, shuffled, f"args[{i}]"))
                else:
                    new_args.append(arg)

            new_kwargs: dict = {}
            for key, value in kwargs.items():
                if isinstance(value, str):
                    shuffled = prng.shuffle_str(value)
                    new_kwargs[key] = shuffled
                    replacements.append((value, shuffled, f"kwargs['{key}']"))
                else:
                    new_kwargs[key] = value

            result: Any = func(*new_args, **new_kwargs)

            _log_message(log_file, func.__name__, args, kwargs, result, replacements)

            return result

        return wrapper

    return decorator


def shuffle_str_args_class(prng, log_file: Optional[str] = None) -> Callable:
    def decorator(cls: Type) -> Type:
        for attr_name, attr_value in cls.__dict__.items():
            if attr_name.startswith('__') and attr_name.endswith('__'):
                continue
            if callable(attr_value):
                setattr(cls, attr_name, shuffle_str_args(prng, log_file)(attr_value))
        return cls

    return decorator