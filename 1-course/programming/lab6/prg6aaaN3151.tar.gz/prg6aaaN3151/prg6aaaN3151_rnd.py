import string
from abc import ABC, abstractmethod


class PRNGBase(ABC):
    @abstractmethod
    def next_int(self) -> int:
        pass

    @abstractmethod
    def next_float(self) -> float:
        pass

    @abstractmethod
    def next_str(self) -> str:
        pass


class XorShiftRNG:
    def __init__(self, seed: int, *, a: int = 13, b: int = 17, c: int = 5) -> None:
        self._state: int = seed
        self._a: int = a
        self._b: int = b
        self._c: int = c

    def _next_state(self) -> int:
        x: int = self._state
        x ^= (x >> self._a)
        x ^= (x << self._b) & 0xFFFFFFFF
        x ^= (x >> self._c)
        self._state = x
        return x

    def __iter__(self):
        return self

    def __next__(self) -> int:
        return self._next_state()


class MyPRNG(PRNGBase):
   
    ALPHABET: str = string.ascii_letters + string.digits
    MAX_STR_LEN: int = 32

    def __init__(self, rng: XorShiftRNG) -> None:
        self._rng: XorShiftRNG = rng

    def next_int(self) -> int:
        return next(self._rng)

    def next_float(self) -> float:
        return self.next_int() / 0x100000000

    def next_str(self) -> str:
        length: int = self.next_int() % self.MAX_STR_LEN + 1
        chars: list[str] = []
        for _ in range(length):
            idx: int = self.next_int() % len(self.ALPHABET)
            chars.append(self.ALPHABET[idx])
        return ''.join(chars)

    def shuffle_str(self, s: str) -> str:
      
        if len(set(s)) <= 1:
            return s
        result: str = s
        while result == s:
            chars: list[str] = list(s)
            n: int = len(chars)
            for i in range(n - 1, 0, -1):
                j: int = self.next_int() % (i + 1)
                chars[i], chars[j] = chars[j], chars[i]
            result = ''.join(chars)
        return result