import pytest
from prg6aaaN3151_rnd import XorShiftRNG, MyPRNG, PRNGBase


def test_xorshift_sequence() -> None:
    rng1: XorShiftRNG = XorShiftRNG(seed=42)
    rng2: XorShiftRNG = XorShiftRNG(seed=42)
    seq1: list[int] = [next(rng1) for _ in range(10)]
    seq2: list[int] = [next(rng2) for _ in range(10)]
    assert seq1 == seq2


def test_xorshift_different_seeds() -> None:
    rng1: XorShiftRNG = XorShiftRNG(seed=1)
    rng2: XorShiftRNG = XorShiftRNG(seed=2)
    seq1: list[int] = [next(rng1) for _ in range(5)]
    seq2: list[int] = [next(rng2) for _ in range(5)]
    assert seq1 != seq2


def test_xorshift_range() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=12345)
    for _ in range(100):
        val: int = next(rng)
        assert 0 <= val <= 0xFFFFFFFF


def test_myprng_next_int() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    val1: int = prng.next_int()
    val2: int = prng.next_int()
    assert isinstance(val1, int)
    assert isinstance(val2, int)
    assert val1 != val2


def test_myprng_next_float() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    for _ in range(100):
        val: float = prng.next_float()
        assert 0.0 <= val < 1.0
        assert isinstance(val, float)


def test_myprng_next_str_type_and_length() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    for _ in range(100):
        val: str = prng.next_str()
        assert isinstance(val, str)
        assert 1 <= len(val) <= MyPRNG.MAX_STR_LEN


def test_myprng_next_str_alphabet() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=7)
    prng: MyPRNG = MyPRNG(rng)
    for _ in range(100):
        val: str = prng.next_str()
        assert all(ch in MyPRNG.ALPHABET for ch in val)


def test_myprng_next_str_deterministic() -> None:
    prng1: MyPRNG = MyPRNG(XorShiftRNG(seed=123))
    prng2: MyPRNG = MyPRNG(XorShiftRNG(seed=123))
    seq1: list[str] = [prng1.next_str() for _ in range(10)]
    seq2: list[str] = [prng2.next_str() for _ in range(10)]
    assert seq1 == seq2


def test_myprng_next_str_varies() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=99)
    prng: MyPRNG = MyPRNG(rng)
    values: list[str] = [prng.next_str() for _ in range(20)]
    assert len(set(values)) > 1


def test_myprng_shuffle_str() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    original: str = "abcdef"
    shuffled: str = prng.shuffle_str(original)
    assert set(original) == set(shuffled)
    assert len(original) == len(shuffled)


def test_myprng_shuffle_str_single_char() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    original: str = "a"
    shuffled: str = prng.shuffle_str(original)
    assert shuffled == "a"


def test_myprng_shuffle_str_empty() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    prng: MyPRNG = MyPRNG(rng)
    original: str = ""
    shuffled: str = prng.shuffle_str(original)
    assert shuffled == ""


def test_myprng_shuffle_str_deterministic() -> None:
    rng1: XorShiftRNG = XorShiftRNG(seed=100)
    rng2: XorShiftRNG = XorShiftRNG(seed=100)
    prng1: MyPRNG = MyPRNG(rng1)
    prng2: MyPRNG = MyPRNG(rng2)
    original: str = "hello world"
    assert prng1.shuffle_str(original) == prng2.shuffle_str(original)


def test_prngbase_requires_next_str() -> None:
    class Incomplete(PRNGBase):
        def next_int(self) -> int:
            return 0

        def next_float(self) -> float:
            return 0.0

    with pytest.raises(TypeError):
        Incomplete()  # type: ignore[abstract]


def test_iteration() -> None:
    rng: XorShiftRNG = XorShiftRNG(seed=1)
    count: int = 0
    for val in rng:
        count += 1
        if count >= 10:
            break
        assert isinstance(val, int)
    assert count == 10