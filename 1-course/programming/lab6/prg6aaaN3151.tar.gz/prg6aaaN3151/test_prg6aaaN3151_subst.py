import pytest
import tempfile
import os
from prg6aaaN3151_rnd import XorShiftRNG, MyPRNG
from prg6aaaN3151_subst import shuffle_str_args, shuffle_str_args_class


@pytest.fixture
def prng() -> MyPRNG:
    rng: XorShiftRNG = XorShiftRNG(seed=42)
    return MyPRNG(rng)


def test_shuffle_str_args_basic(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def greet(name: str) -> str:
        return f"Hello, {name}!"

    result: str = greet("Alice")
    expected_original = "Hello, Alice!"
    assert result != expected_original
    assert len(result) == len(expected_original)
    assert set(result) == set(expected_original)


def test_shuffle_str_args_multiple_args(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def combine(a: str, b: str) -> str:
        return a + " " + b

    result: str = combine("hello", "world")
    original = "hello world"
    assert len(result) == len(original)
    assert set(result.replace(" ", "")) == set("helloworld")


def test_shuffle_str_args_non_string_args(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def mixed(a: str, b: int, c: str) -> str:
        return f"{a}{b}{c}"

    original_b: int = 42
    result: str = mixed("ab", original_b, "cd")
    assert original_b == 42


def test_shuffle_str_args_kwargs(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def format_text(first: str, last: str) -> str:
        return f"{first} {last}"

    result: str = format_text(first="John", last="Doe")
    original = "John Doe"
    assert result != original
    assert len(result) == len(original)
    assert set(result) == set(original)


def test_shuffle_str_args_logging(prng: MyPRNG) -> None:
    with tempfile.NamedTemporaryFile(mode='w+', delete=False) as tmp:
        log_file: str = tmp.name

    try:
        @shuffle_str_args(prng, log_file)
        def test_func(msg: str) -> str:
            return msg[::-1]

        result: str = test_func("abc")
        assert os.path.exists(log_file)
        with open(log_file, 'r', encoding='utf-8') as f:
            content: str = f.read()
            assert "test_func" in content
    finally:
        if os.path.exists(log_file):
            os.unlink(log_file)


def test_shuffle_str_args_preserves_length(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def process(text: str) -> str:
        return text

    original: str = "Python programming"
    result: str = process(original)
    assert len(result) == len(original)
    assert set(result) == set(original)


def test_decorator_on_class(prng: MyPRNG) -> None:
    @shuffle_str_args_class(prng)
    class TestClass:
        def get_message(self, msg: str) -> str:
            return msg

        def combine(self, a: str, b: str) -> str:
            return a + b

    obj: TestClass = TestClass()
    result1: str = obj.get_message("hello")
    result2: str = obj.combine("foo", "bar")
    assert result1 != "hello"
    assert result2 != "foobar"
    assert set(result1) == set("hello")
    assert set(result2) == set("foobar")


def test_decorator_on_single_method(prng: MyPRNG) -> None:
    class Container:
        @shuffle_str_args(prng)
        def echo(self, value: str) -> str:
            return value

    obj: Container = Container()
    original: str = "secret"
    shuffled: str = obj.echo(original)
    assert shuffled != original
    assert set(shuffled) == set(original)


def test_shuffle_str_args_empty_string(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def handle(s: str) -> str:
        return s

    result: str = handle("")
    assert result == ""


def test_shuffle_str_args_single_char(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def handle(s: str) -> str:
        return s

    result: str = handle("X")
    assert result == "X"


def test_return_value_not_shuffled(prng: MyPRNG) -> None:
    @shuffle_str_args(prng)
    def get_hello() -> str:
        return "hello"

    result: str = get_hello()
    assert result == "hello"