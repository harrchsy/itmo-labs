#!/usr/bin/python3
import sys
import random
import struct
import getopt

STUDENT_NAME = "Агакарян Арам Арманович"
STUDENT_GROUP = "N3151"
VARIANT = "2-10-8-4"

# Допустимые буквы 
CYRILLIC_LETTERS = ["а", "в", "е", "к", "м", "н", "о", "р", "с", "т", "у", "х"]

def print_version():
    print(f"{STUDENT_NAME}, гр. {STUDENT_GROUP}")
    print(f"Вариант: {VARIANT}")

def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)

def parse_nonnegative_int(s):
    try:
        value = int(s, 10)
    except ValueError:
        die(f"Ошибка: '{s}' не является числом.")

    if value < 0:
        die(f"Ошибка: '{s}' не является неотрицательным числом.")

    return value

def gen_car_number():
    first = random.choice(CYRILLIC_LETTERS)
    digits1 = random.randint(100, 999)
    l1 = random.choice(CYRILLIC_LETTERS)
    l2 = random.choice(CYRILLIC_LETTERS)
    region = random.randint(10, 99)
    return f"{first}{digits1:03d}{l1}{l2}{region:02d}RUS"

def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "vn:")
    except getopt.GetoptError as err:
        die(f"Ошибка: {err}")

    num_strings = random.randint(10, 1000)

    for opt, arg in opts:
        if opt == "-v":
            print_version()
            return
        if opt == "-n":
            num_strings = parse_nonnegative_int(arg)

    if len(args) != 1:
        die("Ошибка: нужно указать ровно одно имя файла.")

    filename = args[0]
    cnt = num_strings

    # Пустой список => файл нулевого размера
    if cnt == 0:
        try:
            open(filename, "wb").close()
        except OSError as e:
            die(f"Ошибка: не удалось записать файл: {e}.")
        print(f"Успешно: файл '{filename}' создан, строк: 0 (файл нулевого размера)")
        return

    strings = [gen_car_number() for _ in range(cnt)]
    encoded = [s.encode("utf-8") + b"\x00" for s in strings]
    idxs = random.sample(range(cnt), cnt)

    data_first_size = random.randint(4, 32)
    data_first = bytes(random.randint(0, 255) for _ in range(data_first_size))
    if cnt >= 2:
        data_last_size = random.randint(4, 32)
        data_last = bytes(random.randint(0, 255) for _ in range(data_last_size))
    else:
        data_last_size = 0
        data_last = b""

    # Смещения o_k строк s_k от начала файла
    header_end = 4 + cnt * 6
    offs = [0] * cnt
    pos = header_end + data_first_size
    offs[0] = pos
    pos += len(encoded[0])
    for k in range(1, cnt):
        if k == cnt - 1 and cnt >= 2:
            pos += data_last_size
        offs[k] = pos
        pos += len(encoded[k])

    try:
        with open(filename, "wb") as f:
            f.write(struct.pack("<I", cnt))
            for k in range(cnt):
                f.write(struct.pack("<H", idxs[k]))
                f.write(struct.pack("<I", offs[k]))
            f.write(data_first)
            for k in range(cnt):
                if k == cnt - 1 and cnt >= 2:
                    f.write(data_last)
                f.write(encoded[k])
    except OSError as e:
        die(f"Ошибка: не удалось записать файл: {e}.")

    # Диагностический вывод
    print(f"Файл: {filename}")
    print(f"cnt = {cnt}")
    print(f"Заголовок (i,o)-пар: с 0x{4:x} по 0x{header_end:x} ({cnt * 6} байт)")
    print(f"data_first: размер {data_first_size} байт, смещение 0x{header_end:x}")
    if cnt >= 2:
        data_last_offset = offs[-1] - data_last_size
        print(f"data_last:  размер {data_last_size} байт, смещение 0x{data_last_offset:x}")
    else:
        print("data_last:  отсутствует (cnt < 2)")
    print()
    print("Заголовок (k — позиция в файле, idx — позиция в списке, off — смещение строки):")
    for k in range(cnt):
        print(f"  k={k:4d}  idx={idxs[k]:4d}  off=0x{offs[k]:08x} ({offs[k]:7d})  s_k={strings[k]}")
    print()
    print("Порядок строк в списке после загрузки:")
    inv = [0] * cnt
    for k in range(cnt):
        inv[idxs[k]] = k
    for p in range(cnt):
        print(f"  list[{p:4d}] = {strings[inv[p]]}")
    print(f"\nУспешно: файл '{filename}' создан, строк: {cnt}")

if __name__ == "__main__":
    main()
