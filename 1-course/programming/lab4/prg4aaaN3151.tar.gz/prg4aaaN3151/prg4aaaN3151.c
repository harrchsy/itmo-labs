#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <getopt.h>

typedef struct Node
{
    char *data;
    struct Node *next;
    struct Node *prev;
} Node;

typedef struct
{
    Node *head;
    Node *tail;
    int modified;
    unsigned char *data_first;
    size_t data_first_len;
    unsigned char *data_last;
    size_t data_last_len;
} DoubleList;

// Допустимые буквы
static const char *const ALLOWED_LETTERS[] = {
    "\xD0\xB0", // а
    "\xD0\xB2", // в
    "\xD0\xB5", // е
    "\xD0\xBA", // к
    "\xD0\xBC", // м
    "\xD0\xBD", // н
    "\xD0\xBE", // о
    "\xD1\x80", // р
    "\xD1\x81", // с
    "\xD1\x82", // т
    "\xD1\x83", // у
    "\xD1\x85", // х
};
static const size_t ALLOWED_LETTERS_COUNT = sizeof(ALLOWED_LETTERS) / sizeof(ALLOWED_LETTERS[0]);

static int is_allowed_letter(const char *p)
{
    for (size_t i = 0; i < ALLOWED_LETTERS_COUNT; i++)
    {
        if (memcmp(p, ALLOWED_LETTERS[i], 2) == 0)
            return 1;
    }
    return 0;
}

// очистка памяти
void list_clear(DoubleList *list)
{
    Node *curr = list->head;
    while (curr)
    {
        Node *next = curr->next;
        free(curr->data);
        free(curr);
        curr = next;
    }
    list->head = list->tail = NULL;
    free(list->data_first);
    list->data_first = NULL;
    list->data_first_len = 0;
    free(list->data_last);
    list->data_last = NULL;
    list->data_last_len = 0;
}

int is_valid_car_number(const char *s)
{
    if (!s || strlen(s) != 14)
        return 0;
    if (!is_allowed_letter(s))
        return 0;
    if (!isdigit((unsigned char)s[2]) || !isdigit((unsigned char)s[3]) || !isdigit((unsigned char)s[4]))
        return 0;
    if (!is_allowed_letter(s + 5))
        return 0;
    if (!is_allowed_letter(s + 7))
        return 0;
    if (!isdigit((unsigned char)s[9]) || !isdigit((unsigned char)s[10]))
        return 0;
    return (strcmp(s + 11, "RUS") == 0);
}

// списки
void push_back(DoubleList *list, const char *str)
{
    if (!is_valid_car_number(str))
    {
        fprintf(stderr, "Ошибка: неверный формат номера: %s.\n", str);
        return;
    }
    Node *n = malloc(sizeof(Node));
    if (!n)
    {
        fprintf(stderr, "Ошибка: недостаточно памяти.\n");
        exit(1);
    }
    n->data = strdup(str);
    if (!n->data)
    {
        free(n);
        exit(1);
    }
    n->next = NULL;
    n->prev = list->tail;
    if (list->tail)
        list->tail->next = n;
    else
        list->head = n;
    list->tail = n;
    list->modified = 1;
}

void push_front(DoubleList *list, const char *str)
{
    if (!is_valid_car_number(str))
    {
        fprintf(stderr, "Ошибка: неверный формат номера: %s.\n", str);
        return;
    }
    Node *n = malloc(sizeof(Node));
    if (!n)
    {
        fprintf(stderr, "Ошибка: недостаточно памяти.\n");
        exit(1);
    }
    n->data = strdup(str);
    if (!n->data)
    {
        free(n);
        exit(1);
    }
    n->prev = NULL;
    n->next = list->head;
    if (list->head)
        list->head->prev = n;
    else
        list->tail = n;
    list->head = n;
    list->modified = 1;
}

void list_reorder_asc(DoubleList *list)
{
    if (!list->head)
        return;
    int sw;
    Node *p;
    do
    {
        sw = 0;
        p = list->head;
        while (p->next)
        {
            if (strcmp(p->data, p->next->data) > 0)
            {
                char *t = p->data;
                p->data = p->next->data;
                p->next->data = t;
                sw = 1;
                list->modified = 1;
            }
            p = p->next;
        }
    } while (sw);
}

static void die_corrupt(FILE *f, uint16_t *idxs, uint32_t *offs, char **strs,
                        uint32_t cnt, uint32_t *order, char *seen)
{
    fprintf(stderr, "Ошибка: некорректный формат файла.\n");
    if (strs)
        for (uint32_t i = 0; i < cnt; i++)
            free(strs[i]);
    free(idxs);
    free(offs);
    free(strs);
    free(order);
    free(seen);
    if (f)
        fclose(f);
    exit(1);
}

void load_from_file(const char *fn, DoubleList *list)
{
    FILE *f = fopen(fn, "rb");
    if (!f)
        return;

    uint32_t cnt;
    if (fread(&cnt, 4, 1, f) != 1)
    {
        fclose(f);
        return;
    }
    if (cnt == 0)
    {
        fclose(f);
        return;
    }

    uint16_t *idxs = malloc(cnt * sizeof(uint16_t));
    uint32_t *offs = malloc(cnt * sizeof(uint32_t));
    char **strs = calloc(cnt, sizeof(char *));
    uint32_t *order = malloc(cnt * sizeof(uint32_t));
    char *seen = calloc(cnt, 1);

    if (!idxs || !offs || !strs || !order || !seen)
    {
        fprintf(stderr, "Ошибка: недостаточно памяти.\n");
        free(idxs);
        free(offs);
        free(strs);
        free(order);
        free(seen);
        fclose(f);
        exit(1);
    }

    for (uint32_t k = 0; k < cnt; k++)
    {
        if (fread(&idxs[k], 2, 1, f) != 1 || fread(&offs[k], 4, 1, f) != 1)
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
    }

    for (uint32_t k = 0; k < cnt; k++)
    {
        if (idxs[k] >= cnt || seen[idxs[k]])
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
        seen[idxs[k]] = 1;
        order[k] = k;
    }

    for (uint32_t i = 0; i + 1 < cnt; i++)
    {
        for (uint32_t j = 0; j + 1 < cnt - i; j++)
        {
            if (offs[order[j]] > offs[order[j + 1]])
            {
                uint32_t t = order[j];
                order[j] = order[j + 1];
                order[j + 1] = t;
            }
        }
    }

    uint32_t header_end = 4 + cnt * 6;
    if (offs[order[0]] < header_end)
        die_corrupt(f, idxs, offs, strs, cnt, order, seen);

    list->data_first_len = offs[order[0]] - header_end;
    if (list->data_first_len > 0)
    {
        list->data_first = malloc(list->data_first_len);
        if (!list->data_first)
        {
            fprintf(stderr, "Ошибка: недостаточно памяти.\n");
            exit(1);
        }
        if (fseek(f, header_end, SEEK_SET) != 0 ||
            fread(list->data_first, 1, list->data_first_len, f) != list->data_first_len)
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
    }

    for (uint32_t k = 0; k < cnt; k++)
    {
        if (fseek(f, offs[k], SEEK_SET) != 0)
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);

        size_t cp = 16, ln = 0;
        char *b = malloc(cp);
        if (!b)
        {
            fprintf(stderr, "Ошибка: недостаточно памяти.\n");
            exit(1);
        }
        int c;
        while ((c = fgetc(f)) != EOF && c != '\0')
        {
            if (ln + 1 >= cp)
            {
                char *tmp = realloc(b, cp *= 2);
                if (!tmp)
                {
                    free(b);
                    fprintf(stderr, "Ошибка: недостаточно памяти.\n");
                    exit(1);
                }
                b = tmp;
            }
            b[ln++] = c;
        }
        if (c != '\0')
        {
            free(b);
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
        }
        b[ln] = '\0';
        if (!is_valid_car_number(b))
        {
            free(b);
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
        }
        strs[k] = b;
    }

    if (cnt >= 2)
    {
        uint32_t penult_k = order[cnt - 2];
        uint32_t last_k = order[cnt - 1];
        uint32_t penult_end = offs[penult_k] + (uint32_t)strlen(strs[penult_k]) + 1;
        if (offs[last_k] < penult_end)
            die_corrupt(f, idxs, offs, strs, cnt, order, seen);
        list->data_last_len = offs[last_k] - penult_end;
        if (list->data_last_len > 0)
        {
            list->data_last = malloc(list->data_last_len);
            if (!list->data_last)
            {
                fprintf(stderr, "Ошибка: недостаточно памяти.\n");
                exit(1);
            }
            if (fseek(f, penult_end, SEEK_SET) != 0 ||
                fread(list->data_last, 1, list->data_last_len, f) != list->data_last_len)
                die_corrupt(f, idxs, offs, strs, cnt, order, seen);
        }
    }

    uint32_t *inv = malloc(cnt * sizeof(uint32_t));
    if (!inv)
    {
        fprintf(stderr, "Ошибка: недостаточно памяти.\n");
        exit(1);
    }
    for (uint32_t k = 0; k < cnt; k++)
        inv[idxs[k]] = k;
    for (uint32_t p = 0; p < cnt; p++)
        push_back(list, strs[inv[p]]);
    free(inv);

    for (uint32_t k = 0; k < cnt; k++)
        free(strs[k]);
    free(idxs);
    free(offs);
    free(strs);
    free(order);
    free(seen);
    fclose(f);
    list->modified = 0;
}
void save_to_file(const char *fn, DoubleList *list)
{
    FILE *f = fopen(fn, "wb");
    if (!f)
    {
        fprintf(stderr, "Ошибка: не удалось создать файл.\n");
        return;
    }

    uint32_t cnt = 0;
    for (Node *c = list->head; c; c = c->next)
        cnt++;

    if (cnt == 0)
    {
        fclose(f);
        return;
    }

    uint32_t *offs = malloc(cnt * sizeof(uint32_t));
    if (!offs)
    {
        fclose(f);
        return;
    }

    uint32_t header_end = 4 + cnt * 6;
    uint32_t pos = header_end + (uint32_t)list->data_first_len;
    if (cnt == 1)
        pos += (uint32_t)list->data_last_len;
    Node *c = list->head;
    for (uint32_t k = 0; k < cnt; k++)
    {
        if (k == cnt - 1 && cnt >= 2)
            pos += (uint32_t)list->data_last_len;
        offs[k] = pos;
        pos += (uint32_t)strlen(c->data) + 1;
        c = c->next;
    }

    if (fwrite(&cnt, 4, 1, f) != 1)
        goto out;
    for (uint16_t k = 0; k < cnt; k++)
    {
        uint16_t idx = k;
        if (fwrite(&idx, 2, 1, f) != 1)
            goto out;
        if (fwrite(&offs[k], 4, 1, f) != 1)
            goto out;
    }
    if (list->data_first_len > 0 &&
        fwrite(list->data_first, 1, list->data_first_len, f) != list->data_first_len)
        goto out;
    // Для cnt == 1 data_last идёт сразу за data_first перед единственной строкой
    if (cnt == 1 && list->data_last_len > 0 &&
        fwrite(list->data_last, 1, list->data_last_len, f) != list->data_last_len)
        goto out;

    c = list->head;
    for (uint32_t k = 0; k < cnt; k++)
    {
        if (k == cnt - 1 && cnt >= 2 && list->data_last_len > 0)
        {
            if (fwrite(list->data_last, 1, list->data_last_len, f) != list->data_last_len)
                goto out;
        }
        size_t slen = strlen(c->data) + 1;
        if (fwrite(c->data, 1, slen, f) != slen)
            goto out;
        c = c->next;
    }

out:
    free(offs);
    fclose(f);
}

int main(int argc, char *argv[])
{
    int opt;
    while ((opt = getopt(argc, argv, "v")) != -1)
    {
        switch (opt)
        {
        case 'v':
            printf("Агакарян Арам Арманович, гр. N3151\nВариант: 2-10-8-4\n");
            return 0;
        default:
            return 1;
        }
    }

    if (optind >= argc)
    {
        fprintf(stderr, "Ошибка: не задано имя файла.\n");
        return 1;
    }
    if (optind + 1 != argc)
    {
        fprintf(stderr, "Ошибка: лишние аргументы.\n");
        return 1;
    }

    DoubleList list = {NULL, NULL, 0, NULL, 0, NULL, 0};
    load_from_file(argv[optind], &list);

    char *line = NULL;
    size_t len = 0;
    while (printf("> "), getline(&line, &len, stdin) != -1)
    {
        line[strcspn(line, "\r\n")] = 0;
        char *cmd = strtok(line, " "), *p;
        if (!cmd)
            continue;

        if (strcmp(cmd, "push_back") == 0)
        {
            while ((p = strtok(NULL, " ")))
                push_back(&list, p);
        }
        else if (strcmp(cmd, "push_front") == 0)
        {
            char **tks = NULL;
            int tc = 0;
            while ((p = strtok(NULL, " ")))
            {
                char **tmp = realloc(tks, sizeof(char *) * (tc + 1));
                if (!tmp)
                {
                    free(tks);
                    exit(1);
                }
                tks = tmp;
                tks[tc++] = p;
            }
            for (int i = tc - 1; i >= 0; i--)
                push_front(&list, tks[i]);
            free(tks);
        }
        else if (strcmp(cmd, "pop_back") == 0)
        {
            if (strtok(NULL, " "))
                fprintf(stderr, "Ошибка: лишние аргументы.\n");
            else if (list.tail)
            {
                Node *t = list.tail;
                list.tail = t->prev;
                if (list.tail)
                    list.tail->next = NULL;
                else
                    list.head = NULL;
                free(t->data);
                free(t);
                list.modified = 1;
            }
        }
        else if (strcmp(cmd, "pop_front") == 0)
        {
            if (strtok(NULL, " "))
                fprintf(stderr, "Ошибка: лишние аргументы.\n");
            else if (list.head)
            {
                Node *t = list.head;
                list.head = t->next;
                if (list.head)
                    list.head->prev = NULL;
                else
                    list.tail = NULL;
                free(t->data);
                free(t);
                list.modified = 1;
            }
        }
        else if (strcmp(cmd, "reorder_asc") == 0)
        {
            if (strtok(NULL, " "))
                fprintf(stderr, "Ошибка: лишние аргументы.\n");
            else
                list_reorder_asc(&list);
        }
        else if (strcmp(cmd, "dump") == 0)
        {
            p = strtok(NULL, " ");
            if (p)
            {
                if (strtok(NULL, " "))
                {
                    fprintf(stderr, "Ошибка: лишние аргументы.\n");
                    continue;
                }
                FILE *df = fopen(p, "w");
                if (df)
                {
                    for (Node *c = list.head; c; c = c->next)
                        fprintf(df, "%p %p %p %s\n", (void *)c, (void *)c->prev, (void *)c->next, c->data);
                    fclose(df);
                }
                else
                    perror("fopen");
            }
            else
            {
                for (Node *c = list.head; c; c = c->next)
                    printf("%p %p %p %s\n", (void *)c, (void *)c->prev, (void *)c->next, c->data);
            }
        }
        else if (strcmp(cmd, "exit") == 0)
            break;
        else
            fprintf(stderr, "Ошибка: неподдерживаемая команда: '%s'.\n", cmd);
    }

    if (list.modified)
        save_to_file(argv[optind], &list);
    list_clear(&list);
    free(line);
    return 0;
}
