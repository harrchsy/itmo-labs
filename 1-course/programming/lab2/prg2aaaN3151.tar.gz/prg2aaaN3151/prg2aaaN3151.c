#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int parse_int(const char *s, int *x) {
  char *endptr;
  errno = 0;
  long val = strtol(s, &endptr, 10);

  if (endptr == s || *endptr != '\0' || errno != 0)
    return 0;

  if (val <= 0 || val > 1000)
    return 0;

  *x = (int)val;
  return 1;
}

int read_double(double *x) {
  char buf[256];
  char *endptr;

  if (!fgets(buf, sizeof(buf), stdin))
    return 0;

  errno = 0;
  double val = strtod(buf, &endptr);

  if (endptr == buf || errno != 0)
    return 0;

  *x = val;
  return 1;
}

void print_matrix(int n, int m, double a[n][m]) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++)
      printf("%8.3f ", a[i][j]);
    printf("\n");
  }
}

void shift_diagonals(int n, int m, double a[n][m], int T) {
  int debug = getenv("LAB2DEBUG") != NULL;

  for (int V = -(n - 1); V <= m - 1; V++) {

    int start_i = (V < 0) ? -V : 0;
    int start_j = (V > 0) ? V : 0;

    int len = (n - start_i < m - start_j) ? n - start_i : m - start_j;

    if (len <= 1)
      continue;

    double d[len];
    int pi[len], pj[len];

    for (int k = 0; k < len; k++) {
      int i = start_i + k;
      int j = start_j + k;
      d[k] = a[i][j];
      pi[k] = i;
      pj[k] = j;
    }

    int shift = T % len;
    if (shift < 0)
      shift += len;

    if (shift == 0)
      continue;

    if (debug) {
      printf("[DEBUG] Диагональ V=%d, длина=%d, сдвиг=%d, направление=%s\n", V,
             len, shift, (V % 2 == 0) ? "вправо (чётная)" : "влево (нечётная)");
    }

    double tmp[len];

    if (V % 2 == 0) {
      /* четная вправо */
      for (int k = 0; k < len; k++)
        tmp[(k + shift) % len] = d[k];
    } else {
      /* нечетная влево */
      for (int k = 0; k < len; k++)
        tmp[k] = d[(k + shift) % len];
    }

    for (int k = 0; k < len; k++)
      a[pi[k]][pj[k]] = tmp[k];
  }
}

int main(int argc, char *argv[]) {
  int manual = 0;
  int pos = 1;

  if (argc < 3) {
    fprintf(stderr, "Использование: %s [-m] строки столбцы\n", argv[0]);
    fprintf(stderr, "  -m  ручной ввод элементов матрицы\n");
    return 1;
  }

  if (strcmp(argv[pos], "-m") == 0) {
    manual = 1;
    pos++;

    if (argc - pos < 2) {
      fprintf(stderr, "Ошибка: отсутствуют обязательные аргументы после -m\n");
      return 1;
    }
  }

  for (int i = 1; i < argc; i++) {
    if (argv[i][0] == '-' && strcmp(argv[i], "-m") != 0) {
      fprintf(stderr, "Ошибка: опция '%s' не поддерживается\n", argv[i]);
      return 1;
    }
  }

  if (argc - pos != 2) {
    if (argc - pos > 2) {
      fprintf(stderr, "Ошибка: лишние аргументы\n");
    } else {
      fprintf(stderr, "Ошибка: недостаточно аргументов\n");
    }
    return 1;
  }

  int n, m;
  if (!parse_int(argv[pos], &n) || !parse_int(argv[pos + 1], &m)) {
    fprintf(stderr, "Ошибка: некорректные размеры матрицы\n");
    return 1;
  }

  double a[n][m];

  if (manual) {
    printf("Введите элементы матрицы %dx%d:\n", n, m);
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        if (!read_double(&a[i][j])) {
          fprintf(stderr, "Ошибка: некорректный ввод числа\n");
          return 1;
        }
      }
    }
  } else {
    srand((unsigned)time(NULL));
    for (int i = 0; i < n; i++)
      for (int j = 0; j < m; j++)
        a[i][j] = (rand() % 10000) / 100.0;
  }

  printf("Введите T: ");
  char buf[256];
  if (!fgets(buf, sizeof(buf), stdin)) {
    fprintf(stderr, "Ошибка: некорректный ввод T\n");
    return 1;
  }

  char *endptr;
  errno = 0;
  long t = strtol(buf, &endptr, 10);

  if (endptr == buf) {
    fprintf(stderr, "Ошибка: '%s' не является числом\n", buf);
    return 1;
  }

  /* переполнение */
  if (errno == ERANGE) {
    fprintf(stderr, "Ошибка: значение T выходит за диапазон\n");
    return 1;
  }

  /* после числа нет лишних символов */
  while (*endptr == ' ' || *endptr == '\t')
    endptr++;
  if (*endptr != '\0' && *endptr != '\n') {
    fprintf(stderr, "Ошибка: некорректный формат T\n");
    return 1;
  }

  int T = (int)t;

  printf("\nИсходная матрица:\n");
  print_matrix(n, m, a);

  shift_diagonals(n, m, a, T);

  printf("\nРезультат:\n");
  print_matrix(n, m, a);

  return 0;
}
