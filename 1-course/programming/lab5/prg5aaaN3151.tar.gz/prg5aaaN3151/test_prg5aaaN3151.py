import pytest
from prg5aaaN3151 import MyMACList, FormatError, UndoError, RedoError

def test_init_valid():
    lst = MyMACList(["aa:bb:cc:dd:ee:ff", "00:11:22:33:44:55"])
    assert lst == ["aa:bb:cc:dd:ee:ff", "00:11:22:33:44:55"]

def test_init_invalid_type():
    with pytest.raises(TypeError):
        MyMACList([123, "aa:bb:cc:dd:ee:ff"])

def test_init_invalid_format():
    with pytest.raises(FormatError):
        MyMACList(["invalid", "aa:bb:cc:dd:ee:ff"])

def test_append_valid():
    lst = MyMACList()
    lst.append("ab:cd:ef:01:23:45")
    assert lst == ["ab:cd:ef:01:23:45"]

def test_append_invalid():
    lst = MyMACList()
    with pytest.raises(FormatError):
        lst.append("192.168.0.1")

def test_setitem_valid():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa"])
    lst[0] = "bb:bb:bb:bb:bb:bb"
    assert lst[0] == "bb:bb:bb:bb:bb:bb"

def test_setitem_invalid():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa"])
    with pytest.raises(FormatError):
        lst[0] = "not a mac"

def test_undo_basic():
    lst = MyMACList(["a1:b2:c3:d4:e5:f6"])
    lst.append("11:22:33:44:55:66")
    assert lst == ["a1:b2:c3:d4:e5:f6", "11:22:33:44:55:66"]
    lst.undo()
    assert lst == ["a1:b2:c3:d4:e5:f6"]

def test_undo_error():
    lst = MyMACList()
    with pytest.raises(UndoError):
        lst.undo()

def test_redo_basic():
    lst = MyMACList(["aa:bb:cc:dd:ee:ff"])
    lst.append("11:22:33:44:55:66")
    lst.undo()
    assert lst == ["aa:bb:cc:dd:ee:ff"]
    lst.redo()
    assert lst == ["aa:bb:cc:dd:ee:ff", "11:22:33:44:55:66"]

def test_redo_error():
    lst = MyMACList(["00:00:00:00:00:00"])
    with pytest.raises(RedoError):
        lst.redo()

def test_redo_after_new_change():
    lst = MyMACList(["11:11:11:11:11:11"])
    lst.append("22:22:22:22:22:22")
    lst.undo()
    lst.append("33:33:33:33:33:33")
    with pytest.raises(RedoError):
        lst.redo()

def test_extend_valid():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa"])
    lst.extend(["bb:bb:bb:bb:bb:bb", "cc:cc:cc:cc:cc:cc"])
    assert lst == ["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb", "cc:cc:cc:cc:cc:cc"]

def test_extend_invalid():
    lst = MyMACList()
    with pytest.raises(FormatError):
        lst.extend(["bad", "aa:aa:aa:aa:aa:aa"])

def test_insert_valid():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa", "cc:cc:cc:cc:cc:cc"])
    lst.insert(1, "bb:bb:bb:bb:bb:bb")
    assert lst[1] == "bb:bb:bb:bb:bb:bb"

def test_pop_and_undo():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb"])
    lst.pop()
    assert lst == ["aa:aa:aa:aa:aa:aa"]
    lst.undo()
    assert lst == ["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb"]

def test_clear_and_undo():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb"])
    lst.clear()
    assert lst == []
    lst.undo()
    assert lst == ["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb"]

def test_iadd():
    lst = MyMACList(["aa:aa:aa:aa:aa:aa"])
    lst += ["bb:bb:bb:bb:bb:bb"]
    assert lst == ["aa:aa:aa:aa:aa:aa", "bb:bb:bb:bb:bb:bb"]
    lst.undo()
    assert lst == ["aa:aa:aa:aa:aa:aa"]