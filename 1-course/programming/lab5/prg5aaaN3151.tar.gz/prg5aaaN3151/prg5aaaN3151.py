"""
Модуль с классом MyMACList, наследующим от list,
хранящим только MAC-адреса и поддерживающим undo/redo.
"""

import re
from collections import deque

# --- Исключения ---
class FormatError(Exception):
    """Исключение при неверном формате строки."""
    pass

class UndoError(Exception):
    """Исключение при невозможности выполнить undo."""
    pass

class RedoError(Exception):
    """Исключение при невозможности выполнить redo."""
    pass

# --- Регулярное выражение для MAC-адреса ---
# Формат: XX:XX:XX:XX:XX:XX, где X - шестнадцатеричная цифра (0-9, a-f, A-F)
MAC_PATTERN = re.compile(r'^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$')


def validate_mac(value):
    """Проверяет, является ли строка MAC-адресом."""
    if not isinstance(value, str):
        raise TypeError(f"Expected str, got {type(value).__name__}")
    if not MAC_PATTERN.match(value):
        raise FormatError(f"Invalid MAC address format: {value}")
    return value


class MyMACList(list):
    """Список, хранящий только MAC-адреса, с поддержкой undo/redo."""

    def __init__(self, iterable=None):
        self._history = deque()          # стек для undo
        self._redo_stack = deque()       # стек для redo
        self._record_state()             # запоминаем начальное состояние

        if iterable is None:
            super().__init__()
        else:
            # Проверяем все элементы при инициализации
            validated = [validate_mac(item) for item in iterable]
            super().__init__(validated)
            self._record_state()

    def _record_state(self):
        """Сохраняет текущее состояние списка в историю."""
        # Сохраняем копию текущего состояния
        self._history.append(list(self))
        # При новом действии очищаем redo-стек
        self._redo_stack.clear()

    def _check_and_record(self, operation):
        """Выполняет операцию и записывает состояние, если операция успешна."""
        result = operation()
        self._record_state()
        return result

    # --- Переопределение методов, изменяющих список ---

    def append(self, item):
        validated = validate_mac(item)
        super().append(validated)
        self._record_state()

    def insert(self, index, item):
        validated = validate_mac(item)
        super().insert(index, validated)
        self._record_state()

    def extend(self, iterable):
        validated = [validate_mac(i) for i in iterable]
        super().extend(validated)
        self._record_state()

    def __setitem__(self, key, value):
        if isinstance(key, slice):
            # slice: все элементы должны быть валидны
            validated = [validate_mac(v) for v in value]
            super().__setitem__(key, validated)
        else:
            super().__setitem__(key, validate_mac(value))
        self._record_state()

    def __delitem__(self, key):
        super().__delitem__(key)
        self._record_state()

    def pop(self, index=-1):
        result = super().pop(index)
        self._record_state()
        return result

    def remove(self, value):
        # Находим индекс элемента (должен существовать)
        idx = self.index(validate_mac(value))
        super().pop(idx)
        self._record_state()

    def clear(self):
        super().clear()
        self._record_state()

    # += и другие операции через __iadd__
    def __iadd__(self, other):
        validated = [validate_mac(item) for item in other]
        super().__iadd__(validated)
        self._record_state()
        return self

    # --- Undo / Redo ---

    def undo(self):
        """Откатывает последнее изменение."""
        if len(self._history) <= 1:
            raise UndoError("No more undo steps available")
        # Сохраняем текущее состояние в redo перед откатом
        self._redo_stack.append(list(self))
        # Удаляем текущее состояние из истории
        self._history.pop()
        # Восстанавливаем предыдущее состояние
        prev_state = self._history[-1]
        super().clear()
        super().extend(prev_state)

    def redo(self):
        """Повторяет отменённое действие."""
        if not self._redo_stack:
            raise RedoError("No more redo steps available")
        # Текущее состояние должно совпадать с последним в истории
        # (иначе redo невозможен по условию, но мы проверяем по стеку)
        next_state = self._redo_stack.pop()
        self._history.append(next_state)
        super().clear()
        super().extend(next_state)