#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Структура для хранения параметров программы */
typedef struct {
    int show_version;      /* Флаг опции -v */
    int use_color;         /* Флаг опции -c */
    int single_line_only;  /* Флаг опции -n */
    int begin_line;        /* Начальная строка (-b), -1 если не задана */
    int end_line;          /* Конечная строка (-e), -1 если не задана */
    char *input_file;      /* Имя входного файла или NULL */
    char *output_file;     /* Имя выходного файла или NULL */
} Options;

/* Прототипы функций */
void print_version(void);
int parse_options(int argc, char *argv[], Options *opts);
int is_digit_char(char c);
int is_valid_date_time(const char *str, int pos);
void process_file(FILE *input, FILE *output, Options *opts);
void process_line(const char *line, FILE *output, Options *opts, int line_num);

/* Глобальные константы */
#define ANSI_BLUE "\033[34m"
#define ANSI_RESET "\033[0m"

int main(int argc, char *argv[]) {
    Options opts = {0, 0, 0, -1, -1, NULL, NULL};
    FILE *input = stdin;
    FILE *output = stdout;
    int exit_code = 0;

    /* Парсим аргументы командной строки */
    if (parse_options(argc, argv, &opts) != 0) {
        return 1;
    }

    /* Если нужно показать версию - показываем и выходим */
    if (opts.show_version) {
        print_version();
        return 0;
    }

    /* Открываем входной файл, если указан */
    if (opts.input_file != NULL) {
        input = fopen(opts.input_file, "r");
        if (input == NULL) {
            fprintf(stderr, "Ошибка: не удалось открыть файл %s\n", opts.input_file);
            return 2;
        }
    }

    /* Открываем выходной файл, если указан */
    if (opts.output_file != NULL) {
        output = fopen(opts.output_file, "w");
        if (output == NULL) {
            fprintf(stderr, "Ошибка: не удалось создать файл %s\n", opts.output_file);
            if (input != stdin) fclose(input);
            return 2;
        }
    }

    /* Обрабатываем файл */
    process_file(input, output, &opts);

    /* Закрываем файлы */
    if (input != stdin) fclose(input);
    if (output != stdout) fclose(output);

    return exit_code;
}

/* Функция вывода информации о версии */
void print_version(void) {
    printf("Студент: Агакарян Арам Арманович, гр. N3151\n");
    printf("Вариант: 8-1-1-4\n");
}

/* Функция парсинга опций командной строки */
int parse_options(int argc, char *argv[], Options *opts) {
    int i;
    int file_arg_count = 0;

    /* Проходим по всем аргументам */
    for (i = 1; i < argc; i++) {
        /* Если аргумент начинается с '-', это опция */
        if (argv[i][0] == '-') {
            if (strcmp(argv[i], "-v") == 0) {
                opts->show_version = 1;
            } else if (strcmp(argv[i], "-c") == 0) {
                opts->use_color = 1;
            } else if (strcmp(argv[i], "-n") == 0) {
                opts->single_line_only = 1;
            } else if (strncmp(argv[i], "-b=", 3) == 0) {
                /* Парсим число после -b= */
                char *num_str = argv[i] + 3;
                char *endptr;
                long val = strtol(num_str, &endptr, 10);
                if (*endptr != '\0' || val < 1) {
                    fprintf(stderr, "Ошибка: %s не является допустимым числом для -b\n", num_str);
                    return 1;
                }
                opts->begin_line = (int)val;
            } else if (strncmp(argv[i], "-e=", 3) == 0) {
                /* Парсим число после -e= */
                char *num_str = argv[i] + 3;
                char *endptr;
                long val = strtol(num_str, &endptr, 10);
                if (*endptr != '\0' || val < 1) {
                    fprintf(stderr, "Ошибка: %s не является допустимым числом для -e\n", num_str);
                    return 1;
                }
                opts->end_line = (int)val;
            } else {
                fprintf(stderr, "Ошибка: неподдерживаемая опция %s\n", argv[i]);
                return 1;
            }
        } else {
            /* Это не опция, значит имя файла */
            if (file_arg_count == 0) {
                opts->input_file = argv[i];
                file_arg_count++;
            } else if (file_arg_count == 1) {
                opts->output_file = argv[i];
                file_arg_count++;
            } else {
                fprintf(stderr, "Ошибка: слишком много аргументов\n");
                return 1;
            }
        }
    }

    /* Проверка корректности диапазона строк */
    if (opts->begin_line != -1 && opts->end_line != -1) {
        if (opts->begin_line > opts->end_line) {
            fprintf(stderr, "Ошибка: начальная строка (%d) больше конечной (%d)\n",
                    opts->begin_line, opts->end_line);
            return 1;
        }
    }

    return 0;
}

/* Проверка, является ли символ цифрой */
int is_digit_char(char c) {
    return c >= '0' && c <= '9';
}

/* Проверка корректности даты и времени в позиции pos */
int is_valid_date_time(const char *str, int pos) {
    int i = pos;
    int len = strlen(str);

    /* Проверяем, что есть достаточно места для полной даты */
    if (pos + 19 > len) return 0;

    /* Проверяем формат HH:MM:SS dd.mm.yyyy */
    /* HH - часы (00-23) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1])) return 0;
    int hours = (str[i] - '0') * 10 + (str[i+1] - '0');
    if (hours > 23) return 0;
    i += 2;

    /* : */
    if (str[i] != ':') return 0;
    i++;

    /* MM - минуты (00-59) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1])) return 0;
    int minutes = (str[i] - '0') * 10 + (str[i+1] - '0');
    if (minutes > 59) return 0;
    i += 2;

    /* : */
    if (str[i] != ':') return 0;
    i++;

    /* SS - секунды (00-59) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1])) return 0;
    int seconds = (str[i] - '0') * 10 + (str[i+1] - '0');
    if (seconds > 59) return 0;
    i += 2;

    /* Пробел или перенос строки */
    if (str[i] != ' ' && str[i] != '\n') return 0;
    i++;

    /* dd - день (01-31) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1])) return 0;
    int day = (str[i] - '0') * 10 + (str[i+1] - '0');
    if (day < 1 || day > 31) return 0;
    i += 2;

    /* . */
    if (str[i] != '.') return 0;
    i++;

    /* mm - месяц (01-12) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1])) return 0;
    int month = (str[i] - '0') * 10 + (str[i+1] - '0');
    if (month < 1 || month > 12) return 0;
    i += 2;

    /* . */
    if (str[i] != '.') return 0;
    i++;

    /* yyyy - год (4 цифры) */
    if (!is_digit_char(str[i]) || !is_digit_char(str[i+1]) ||
        !is_digit_char(str[i+2]) || !is_digit_char(str[i+3])) return 0;

    return 1; /* Формат корректен */
}

/* Обработка всего файла */
void process_file(FILE *input, FILE *output, Options *opts) {
    char *buffer = NULL;
    size_t total_read = 0;
    char chunk[4096];
    size_t bytes_read;

    /* Читаем весь файл в буфер */
    while ((bytes_read = fread(chunk, 1, sizeof(chunk), input)) > 0) {
        char *new_buffer = realloc(buffer, total_read + bytes_read + 1);
        if (new_buffer == NULL) {
            free(buffer);
            return;
        }
        buffer = new_buffer;
        memcpy(buffer + total_read, chunk, bytes_read);
        total_read += bytes_read;
    }

    if (buffer != NULL) {
        buffer[total_read] = '\0';

        /* Обрабатываем содержимое */
        process_line(buffer, output, opts, 0);

        free(buffer);
    }
}

/* Обработка текста */
void process_line(const char *text, FILE *output, Options *opts, int unused) {
    int i = 0;
    int len = strlen(text);
    int line_num = 1;

    (void)unused; /* Параметр не используется */

    while (i < len) {
        /* Отслеживаем номер строки */
        if (text[i] == '\n') {
            line_num++;
        }

        /* Проверяем, начинается ли здесь дата-время */
        /* Длина шаблона HH:MM:SS dd.mm.yyyy = 19 символов */
        if (i + 19 <= len && is_valid_date_time(text, i)) {
            /* Определяем, в каком диапазоне строк находится дата */
            int date_line_start = line_num;
            int j;

            /* Проверяем опции -b и -e */
            int should_process = 1;
            if (opts->begin_line != -1 && date_line_start < opts->begin_line) {
                should_process = 0;
            }
            if (opts->end_line != -1 && date_line_start > opts->end_line) {
                should_process = 0;
            }

            /* Проверяем опцию -n (пропускать даты с переносом строки внутри) */
            int has_newline = 0;
            if (opts->single_line_only) {
                for (j = 0; j < 19; j++) {
                    if (text[i + j] == '\n') {
                        has_newline = 1;
                        break;
                    }
                }
            }

            if (should_process && !has_newline) {

                /* Выделяем найденную дату */
                if (opts->use_color) {
                    /* Используем ANSI-цвет (синий) */
                    fprintf(output, "%s", ANSI_BLUE);
                    for (j = 0; j < 19; j++) {
                        fputc(text[i + j], output);
                    }
                    fprintf(output, "%s", ANSI_RESET);
                    i += 19;
                } else {
                    /* Используем Markdown (курсив) */
                    fputc('*', output);
                    for (j = 0; j < 19; j++) {
                        fputc(text[i + j], output);
                    }
                    fputc('*', output);
                    i += 19;
                }
            } else {
                /* Не выделяем, просто выводим символ */
                fputc(text[i], output);
                i++;
            }
        } else {
            /* Просто выводим символ */
            fputc(text[i], output);
            i++;
        }
    }
}
